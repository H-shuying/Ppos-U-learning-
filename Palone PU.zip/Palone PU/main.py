import numpy as np
import torch
from utils.utils_data import generate_Palone_loaders, get_model, generate_Palone_data
import argparse
import os
from utils.utils_models import linear_model, mlp_model
from utils.utils_loss import logistic_loss, sigmoid_loss #cross_entropy_loss
from cifar_models import resnet
from algorithms import *
from sklearn.metrics import  auc

from mpe import  *

import matplotlib
import matplotlib.pyplot as plt

i = 0
Acc_list = []
TPR_list = []
FPR_list = []
precision_list = []
F1_list = []

for i in range(0,1) :

    parser = argparse.ArgumentParser()

    parser.add_argument('-lr', help='optimizer\'s learning rate', default=1e-3, type=float)
    parser.add_argument('-bs', help='batch_size of ordinary labels.', default=2000, type=int)
    parser.add_argument('-ds', help='specify a dataset', default='mnist', type=str, required=False)
    parser.add_argument('-mo', help='model name', default='mlp', choices=['linear', 'mlp', 'resnet'], type=str, required=False)
    parser.add_argument('-ep', help='number of epochs', type=int, default=100)
    parser.add_argument('-wd', help='weight decay', default=1e-5, type=float)
    parser.add_argument('-lo', help='specify a loss function', default='sigmoid', type=str, choices=['logistic', 'sigmoid', 'cross'], required=False)
    parser.add_argument('-me', help='specify a method', default='PaloneUnbiased', type=str, choices=['PaloneUnbiased'], required=False)
    parser.add_argument('-uci', help = 'Is UCI datasets?', default=0, type=int, choices=[0,1], required=False)
    parser.add_argument('-n', help = 'number of unlabeled data pairs', default=15000, type=int, required=False)
    parser.add_argument('-prior', help = 'class (positive) prior', default=0.2, type=float, required=False)
    parser.add_argument('-gpu', help = 'used gpu id', default='0', type=str, required=False)

    args = parser.parse_args()
    device = torch.device("cuda:"+args.gpu if torch.cuda.is_available() else "cpu")

    if args.lo == 'logistic':
        loss_fn = logistic_loss

    if args.lo == 'sigmoid':
        loss_fn = sigmoid_loss


    if  args.ds == 'mnist'  or args.ds == 'fashion':
        args.n =15000
    elif args.ds == 'cifar10':
        args.n = 6000
    elif args.ds == 'cifar100':
        args.n = 2000
    elif args.ds == 'svhn':
        args.n = 4000

    def build_file_name(dataset, method,  prior, loss, phase, figure):
        if figure:
            format = '.png'
        else:
            format = '.txt'
        return (os.path.dirname(os.path.realpath(__file__)) +
                '/output/' + dataset + '/' +
                method + '_' +
                str(prior) + '_' +
                loss + '_' +
                phase + '_' + format)

    def plot_loss(np_loss_test, np_loss_train, nb_epoch):
        plt.xlim(1, nb_epoch, 1)
        plt.plot(range(1, nb_epoch+1), np_loss_test, label='Test')
        plt.plot(range(1, nb_epoch+1), np_loss_train, label='Train')
        plt.title('Loss over ' + str(nb_epoch) + ' Epochs', size=15)
        plt.legend()
        plt.grid(True)
        #绘制损失函数的图像

    xa, xb, xc,  given_ya, given_yb, given_yc, xt, yt, dim = generate_Palone_data(args)

    given_train_loader, test_loader = generate_Palone_loaders(xa, xb, xc,  given_ya, given_yb, given_yc, xt, yt, args.bs)
    model = get_model(args, dim, device)

    loss_train, loss_test, Acc, TPR, FPR, precision, F1 = PaloneUnbiased(model, given_train_loader, test_loader, args, loss_fn, device)
    print("PaloneUnbiased Accuracy:", Acc, 'TPR:', np.mean(TPR), 'FPR:', np.mean(FPR), 'precision:', np.mean(precision), 'F1:', np.mean(F1))

    Acc_list.extend([Acc])
    TPR_list.extend([TPR])
    FPR_list.extend([FPR])
    precision_list.extend([precision])
    F1_list.extend([F1])

    np_loss_test = np.array(loss_test)
    np_loss_train = np.array(loss_train)
    np_TPR = np.array(TPR)
    np_FPR = np.array(FPR)

    # 计算AUC（曲线下面积）
    # roc_auc = auc(np_TPR, np_FPR)

    np_precision = np.array(precision)
    np_F1 = np.array(F1)
    loss_test_file = build_file_name(args.ds, args.me, args.prior, args.lo, phase='test', figure=False)
    loss_train_file = build_file_name(args.ds, args.me, args.prior, args.lo, phase='train', figure=False)

    np.savetxt(loss_test_file, np_loss_test, newline="\r\n")
    np.savetxt(loss_train_file, np_loss_train, newline="\r\n")


    plot_loss(np_loss_test, np_loss_train, args.ep)
    figure_file = build_file_name(args.ds, args.me, args.prior, args.lo, phase='test', figure=True)
    plt.savefig(figure_file)

    print('method:{}    lr:{}    wd:{}'.format(args.me, args.lr, args.wd))
    print('loss:{}    prior:{}'.format(args.lo, args.prior))
    print('model:{}    dataset:{}'.format(args.mo, args.ds))
    print('num of sample:{}'.format(args.n))

mean = np.mean(Acc_list)
std = np.std(Acc_list)
TPR_mean = np.mean(TPR_list)
TPR_std = np.std(TPR_list)
FPR_mean = np.mean(FPR_list)
FPR_std = np.std(FPR_list)
precision_mean = np.mean(precision_list)
precision_std = np.std(precision_list)
F1_mean = np.mean(F1_list)
F1_std = np.std(F1_list)
print('mean:', mean,  'std:', std)
print('TPR_mean', TPR_mean, 'TPR_std', TPR_std)
print('FPR_mean', FPR_mean, 'FPR_std', FPR_std)
print('precision_mean', precision_mean, 'precision_std', precision_std)
print('F1_mean', F1_mean, 'F1_mean', F1_mean)