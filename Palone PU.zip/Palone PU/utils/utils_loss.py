import torch
import torch.nn as nn

def logistic_loss(pred):
     negative_logistic = nn.LogSigmoid()
     logistic = -1. * negative_logistic(pred)
     return logistic

def sigmoid_loss(pred):
     positive_sigmoid = nn.Sigmoid()
     sigmoid = 1-positive_sigmoid(pred)
     return sigmoid

# def cross_entropy_loss(pred):
#      cross_loss =  nn.CrossEntropyLoss()
#      cross = cross_loss(pred)
#      return cross
