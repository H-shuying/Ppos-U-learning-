import sys
import os
import numpy as np
import torch
import torchvision.transforms as transforms
import torchvision.datasets as dsets
import torch.utils.data as data
import torchvision.models as models
from scipy.special import comb
from torch.utils.data.sampler import SubsetRandomSampler
from utils.utils_models import linear_model, mlp_model
from cifar_models import resnet
import math
from scipy.io import arff
import pandas as pd
from sklearn.model_selection import train_test_split
from scipy.io import loadmat
import scipy.io as sio
from scipy import stats

def synth_Palone_train_dataset(args, prior, positive_train_data, negative_train_data):
    positive_train_data = positive_train_data[torch.randperm(positive_train_data.shape[0])]
    negative_train_data = negative_train_data[torch.randperm(negative_train_data.shape[0])] # shuffle the given data

    pp_prior = prior**2
    pn_prior = prior*(1-prior)
    np_prior = prior*(1-prior)
    n = args.n
    total_prior = pp_prior + pn_prior + np_prior

    pp_number = math.floor(n * (pp_prior / total_prior))
    pn_number = math.floor(n * (pn_prior / total_prior))
    np_number =  n - pp_number - pn_number

    U_number = args.n
    U_prior = prior
    U_p = math.floor(U_number * U_prior)
    U_n = math.floor( U_number - U_p)

    xpp_p1 = positive_train_data[:pp_number, :]
    xpp_p2 = positive_train_data[pp_number:2*pp_number,:]
    xpn_p = positive_train_data[2*pp_number:2*pp_number+pn_number, :]
    xpn_n = negative_train_data[:pn_number,:]
    xnp_n  = negative_train_data[pn_number: pn_number+np_number, :]
    xnp_p = positive_train_data[ 2*pp_number+pn_number:2*pp_number+pn_number+ np_number, :]
    x_up =  positive_train_data[-U_p:,:]
    x_un =  negative_train_data[-U_n:,:]

    x1 = torch.cat((xpp_p1, xpn_p, xnp_n), dim=0)
    x2 = torch.cat((xpp_p2 , xpn_n, xnp_p), dim=0)
    x3= torch.cat((x_up, x_un), dim=0)
    given_y1 = torch.cat((torch.ones(pp_number), torch.ones(pn_number), torch.ones(np_number)), dim=0)
    given_y2 = torch.cat((-torch.ones(pp_number), -torch.ones(pn_number), -torch.ones(np_number)), dim=0)
    given_y3 = torch.cat((torch.zeros(U_p), torch.zeros(U_n)), dim=0)

    print(x1.shape, x2.shape,  given_y1.shape, given_y2.shape, given_y3.shape)
    return x1, x2, x3,  given_y1, given_y2, given_y3

def synth_test_dataset(prior, positive_test_data, negative_test_data):
    num_p = positive_test_data.shape[0]
    num_n = negative_test_data.shape[0]
    if prior == 0.1:
        nn = num_n
        np = int(num_n * 0.11)
    elif prior == 0.2:
        nn = num_n
        np = int(num_n*0.25)
    elif prior == 0.51:
        if num_p > num_n:
            nn = num_n
            np = num_n
        else:
            nn = num_p
            np = num_p
    elif prior == 0.6:
        if num_p > num_n:
            nn = num_n
            np = num_n
        else:
            nn = num_p
            np = num_p
    elif prior == 0.8:
        np = num_p
        nn = int(num_p*0.25)
    else:
        np = num_p
        nn = num_n        
    x = torch.cat((positive_test_data[:np, :], negative_test_data[:nn, :]), dim=0)
    y = torch.cat((torch.ones(np), -torch.ones(nn)), dim=0)
    return x, y

#迭代，DataLoader通过参数自动把取出来的数据整理成批次
def generate_Palone_loaders(xa, xb, xc,  given_ya, given_yb, given_yc, xt, yt, batch_size):
    x_train = torch.cat((xa, xb, xc), dim=0)
    y_given = torch.cat((given_ya, given_yb, given_yc), dim=0)
    print(x_train.shape, y_given.shape, )
    given_train_set = torch.utils.data.TensorDataset(x_train, y_given)
    test_set = torch.utils.data.TensorDataset(xt, yt)
    given_train_loader = torch.utils.data.DataLoader(dataset=given_train_set, batch_size=batch_size, shuffle=True, num_workers=0)
    test_loader = torch.utils.data.DataLoader(dataset=test_set, batch_size=batch_size, shuffle=True, num_workers=0)
    return given_train_loader,  test_loader

def convert_to_binary_data(dataname, train_data, train_labels, test_data, test_labels):
    train_index = torch.arange(train_labels.shape[0])
    test_index = torch.arange(test_labels.shape[0])
    if dataname == 'cifar10':
        positive_train_index = torch.cat((torch.cat((torch.cat((torch.cat((train_index[train_labels==0],train_index[train_labels==2]),dim=0),train_index[train_labels==4]),dim=0),train_index[train_labels==6]),dim=0),train_index[train_labels==8]),dim=0)
        negative_train_index = torch.cat((torch.cat((torch.cat((torch.cat((train_index[train_labels==1],train_index[train_labels==3]),dim=0),train_index[train_labels==5]),dim=0),train_index[train_labels==7]),dim=0),train_index[train_labels==9]),dim=0)
        positive_test_index = torch.cat((torch.cat((torch.cat((torch.cat((torch.cat((test_index[test_labels==2],test_index[test_labels==3]),dim=0),test_index[test_labels==4]), dim=0),test_index[test_labels==5]),dim=0),test_index[test_labels==6]),dim=0),test_index[test_labels==7]),dim=0)
        negative_test_index = torch.cat((torch.cat((torch.cat((test_index[test_labels==0],test_index[test_labels==1]),dim=0),test_index[test_labels==8]),dim=0),test_index[test_labels==9]),dim=0)
    elif dataname == 'cifar100':
        positive_train_index = train_index[train_labels % 2 == 0]
        negative_train_index = train_index[train_labels % 2 == 1]
        positive_test_index = test_index[test_labels % 2 == 0]
        negative_test_index = test_index[test_labels % 2 == 1]
    elif dataname == 'mnist' or dataname == 'fashion'  or dataname == 'svhn':
        #torch.cat按行拼接
        positive_train_index = torch.cat((torch.cat((torch.cat((torch.cat((train_index[train_labels==0],train_index[train_labels==2]),dim=0),train_index[train_labels==4]),dim=0),train_index[train_labels==6]),dim=0),train_index[train_labels==8]),dim=0)
        negative_train_index = torch.cat((torch.cat((torch.cat((torch.cat((train_index[train_labels==1],train_index[train_labels==3]),dim=0),train_index[train_labels==5]),dim=0),train_index[train_labels==7]),dim=0),train_index[train_labels==9]),dim=0)
        positive_test_index = torch.cat((torch.cat((torch.cat((torch.cat((test_index[test_labels==0],test_index[test_labels==2]),dim=0),test_index[test_labels==4]),dim=0),test_index[test_labels==6]),dim=0),test_index[test_labels==8]),dim=0)
        negative_test_index = torch.cat((torch.cat((torch.cat((torch.cat((test_index[test_labels==1],test_index[test_labels==3]),dim=0),test_index[test_labels==5]),dim=0),test_index[test_labels==7]),dim=0),test_index[test_labels==9]),dim=0)
    else:
        positive_train_index = train_index[train_labels==1]
        negative_train_index = train_index[train_labels==-1]
        positive_test_index = test_index[test_labels==1]
        negative_test_index = test_index[test_labels==-1]
    positive_train_data = train_data[positive_train_index, :].float()
    negative_train_data = train_data[negative_train_index, :].float()
    positive_test_data = test_data[positive_test_index, :].float()
    negative_test_data = test_data[negative_test_index, :].float()
    return positive_train_data, negative_train_data, positive_test_data, negative_test_data

def prepare_mnist_data():
    ordinary_train_dataset = dsets.MNIST(root='./data/mnist', train=True, transform=transforms.ToTensor(), download=True)
    test_dataset = dsets.MNIST(root='./data/mnist', train=False, transform=transforms.ToTensor())
    train_data = ordinary_train_dataset.data.reshape(-1, 1, 28, 28)
    train_labels = ordinary_train_dataset.targets
    test_data = test_dataset.data.reshape(-1, 1, 28, 28)
    test_labels = test_dataset.targets
    dim = 28*28
    return train_data, train_labels, test_data, test_labels, dim


def prepare_svhn_data():
    train_transform = transforms.Compose(
        [transforms.ToTensor(),  # transforms.RandomHorizontalFlip(), transforms.RandomCrop(32,4),
         transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])
    test_transform = transforms.Compose(
        [transforms.ToTensor(),
         transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])


    train_dataset = dsets.SVHN(root='./data/SVHN', split= 'train', download = False, transform=train_transform)
    test_dataset = dsets.SVHN(root='./data/SVHN',  split= 'test',  download = False, transform=test_transform)

    # dataname =  "data/"+args.ds+".mat"
    # current_data = sio.loadmat(dataname)


    train_data = train_dataset.data
    train_label = train_dataset.labels
    test_data = test_dataset.data
    test_label =  test_dataset.labels

    train_data = torch.from_numpy(train_data).float()
    train_label = torch.from_numpy(train_label).float()
    test_data  = torch.from_numpy(test_data).float()
    test_label = torch.from_numpy(test_label).float()

    train_data = train_data.reshape(-1,3,32,32)
    test_data = test_data.reshape(-1,3,32,32)
    train_labels =  train_label.reshape(-1)
    test_labels  = test_label.reshape(-1)


    train_labels[train_labels == 10] = 0
    test_labels[test_labels == 10] = 0

    dim = 32*32

    return train_data, train_labels, test_data, test_labels, dim

def prepare_fashion_data():
    ordinary_train_dataset = dsets.FashionMNIST(root='./data/FashionMnist',  train=True, transform=transforms.ToTensor(), download=True)
    test_dataset = dsets.FashionMNIST(root='./data/FashionMnist', train=False, transform=transforms.ToTensor(), download=True)
    train_data = ordinary_train_dataset.data.reshape(-1, 1, 28, 28)
    train_labels = ordinary_train_dataset.targets
    test_data = test_dataset.data.reshape(-1, 1, 28, 28)
    test_labels = test_dataset.targets
    dim = 28*28
    return train_data, train_labels, test_data, test_labels, dim

def prepare_cifar10_data():
    train_transform = transforms.Compose(
        [transforms.ToTensor(), # transforms.RandomHorizontalFlip(), transforms.RandomCrop(32,4),
         transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))])#数据转化为pytorch张量并且进行归一化操作
    test_transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.4914, 0.4822, 0.4465), (0.247, 0.243, 0.261))])
    ordinary_train_dataset = dsets.CIFAR10(root='./data', train=True, transform=train_transform, download=True)
    test_dataset = dsets.CIFAR10(root='./data', train=False, transform=test_transform)
    train_data = torch.from_numpy(ordinary_train_dataset.data) # because data is a numpy type
    dim0, dim1, dim2, dim3 = train_data.shape # dim3 = 3
    train_data = train_data.reshape(dim0, dim3, dim1, dim2).float()
    train_labels = ordinary_train_dataset.targets
    train_labels = torch.tensor(train_labels).float() # because train_labels is a list type
    test_data = torch.from_numpy(test_dataset.data)
    dim0, dim1, dim2, dim3 = test_data.shape # dim3 = 3
    test_data = test_data.reshape(dim0, dim3, dim1, dim2).float()
    test_labels = test_dataset.targets
    test_labels = torch.tensor(test_labels).float()
    dim = 32*32
    return train_data, train_labels, test_data, test_labels, dim

def prepare_cifar100_data():
    # 定义数据预处理
    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

    # 下载 CIFAR-100 数据集
    train_dataset = dsets.CIFAR100(root='./data', train=True,download=True, transform=transform)
    test_dataset = dsets.CIFAR100(root='./data', train=False,download=True, transform=transform)
    train_data = torch.from_numpy(train_dataset.data)  # because data is a numpy type
    dim0, dim1, dim2, dim3 = train_data.shape  # dim3 = 3
    train_data = train_data.reshape(dim0, dim3, dim1, dim2).float()
    train_labels = train_dataset.targets
    train_labels = torch.tensor(train_labels).float()  # because train_labels is a list type
    test_data = torch.from_numpy(test_dataset.data)
    dim0, dim1, dim2, dim3 = test_data.shape  # dim3 = 3
    test_data = test_data.reshape(dim0, dim3, dim1, dim2).float()
    test_labels = test_dataset.targets
    test_labels = torch.tensor(test_labels).float()
    dim = 32 * 32
    return train_data, train_labels, test_data, test_labels, dim

def get_model(args, dim, device):
    # global model
    if args.ds == 'cifar10' or args.ds =='svhn' or args.ds == 'cifar100':
        if args.mo == 'resnet':
            model = resnet(depth=32, num_classes=1).to(device)
    else:
        if args.mo == 'linear':
            model  = linear_model(input_dim=dim, output_dim=1).to(device)
        elif args.mo == 'mlp':
            model  = mlp_model(input_dim=dim, hidden_dim=100, output_dim=1).to(device)
    return model

def generate_Palone_data(args):
    if args.ds == 'mnist':
        train_data, train_labels, test_data, test_labels, dim = prepare_mnist_data()
    elif args.ds == 'fashion':
        train_data, train_labels, test_data, test_labels, dim = prepare_fashion_data()
    elif args.ds == 'cifar10':
        train_data, train_labels, test_data, test_labels, dim = prepare_cifar10_data()
    elif args.ds == 'cifar100':
        train_data, train_labels, test_data, test_labels, dim = prepare_cifar100_data()
    elif args.ds == 'svhn':
        train_data, train_labels, test_data, test_labels, dim = prepare_svhn_data()
    print("#original train:", train_data.shape, "#original test", test_data.shape)
    positive_train_data, negative_train_data, positive_test_data, negative_test_data = convert_to_binary_data(args.ds, train_data, train_labels, test_data, test_labels)
    print("#all train positive:", positive_train_data.shape, "#all train negative:", negative_train_data.shape, "#all test positive:", positive_test_data.shape, "#all test negative:", negative_test_data.shape)
    x1, x2, x3,  given_y1, given_y2, given_y3 = synth_Palone_train_dataset(args, args.prior, positive_train_data, negative_train_data)
    xt, yt = synth_test_dataset(args.prior, positive_test_data, negative_test_data)
    print("#test positive:", (yt==1).sum(), "#test negative:", (yt==-1).sum())

    return x1, x2, x3,  given_y1, given_y2, given_y3, xt, yt, dim